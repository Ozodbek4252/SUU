<?php
$arr = [];
$arr = [
    "Реквизиты" => "Register",
    "Зарегистрироваться" => "Register",
    "Пароль"=>"Password",
    "Без логотипа"=>"No logo",
    "С вашим логотипом"=>"with your logo",
    " я ... покупатель"=>" I am ... buyer",
    "г. Ташкент, Юнусабадский район, ул.Ахмад Дониша 26А"=>"Tashkent, Yunusabad district, Ahmad Donish st. 26A",
    "Юнусабадский Филиал"=>"Yunusabad Branch",
    "ВАША КОРЗИНА ПУСТА"=>"YOUR BASKET IS EMPTY",
    "количество" =>"more",
    "Выберите количество блоков"=>"Choose the number of blocks",
    "Печать логотипа" => "Logo printing",

    "cartFormTitle"=>"I am a ... buyer",
    "cartFormOption1"=>"new",
    "cartFormOption2"=>"constant",
    "cartFormDelivery1"=>"necessary",
    "cartFormDelivery2"=>"unnecessary",
    "cartFormPaymentM1"=>"Cash",
    "cartFormPaymentM2"=>"Card",
    "cartFormPayBtn"=>"Pay",
    "cartReqTitle"=>"Requisites",
    "cartReqResip"=>"Recipient",
    "cartReqAddress"=>"Tashkent city, Yunusabad district, Ahmad Donish street 26A",
    "cartReqTIN"=>"TIN",
    "cartReqBC"=>"B/C",
    "cartReqBCBody"=>"2020 8000 2010 3340 5001 PJSCB \"ORIENT FINANCE\" Yunusabad Branch",
    "cartReqIFI"=>"IFI",
    "cartReqNCKEA"=>"NCKEA",

    "honeOrderPrice"=>"Subtotal",
    "honeOrderDelivery"=>"Delivery",
    "honeOrderButton"=>"Order",

    "footerAddress"=>"Address",

    "homePlaceholderInputName"=>"Name",
    "homeContactPhone"=>"Phone",

];
return $arr;