<?php
$arr = [];
$arr = [
    "Зарегистрироваться"=>"Roʻyxatdan oʻtish",
    "Пароль"=>"Parol",
    "Без логотипа"=>"Logotipsiz",
    "С вашим логотипом"=>"Logotip bilan",
    " я ... покупатель"=>" Men... xaridorman",
    "Реквизиты"=>"Tafsilotlar",
    "г. Ташкент, Юнусабадский район, ул.Ахмад Дониша 26А"=>"Toshkent, Yunusobod tumani, Ahmad Donish ko‘chasi, 26A",
    "Юнусабадский Филиал"=>"Yunusobod filiali",
    "ВАША КОРЗИНА ПУСТА"=>"SAVATINGIZ BO'SH",
    "количество"=>"Ko'proq",
    "Выберите количество блоков"=>"Bloklar sonini tanlang",
    "Печать логотипа"=>"Logotip chop etish",

    "cartFormTitle"=>"Men ... xaridorman",
    "cartFormOption1"=>"yangi",
    "cartFormOption2"=>"doimiy",
    "cartFormDelivery1"=>"kerak",
    "cartFormDelivery2"=>"kerak emas",
    "cartFormPaymentM1"=>"Naqd pul",
    "cartFormPaymentM2"=>"Karta",
    "cartFormPayBtn"=>"To'lov",
    "cartReqTitle"=>"Rekvizitlar",
    "cartReqResip"=>"Qabul qiluvchi",
    "cartReqAddress"=>"Toshkent shahri, Yunusobod tumani, Ahmad Donish ko‘chasi 26A",
    "cartReqTIN"=>"SIR",
    "cartReqBC"=>"B/S",
    "cartReqBCBody"=>"2020 8000 2010 3340 5001 PJSCB \"ORIENT FINANCE\" Yunusabad Branch",
    "cartReqIFI"=>"XMI",
    "cartReqNCKEA"=>"IIFTMT",

    "honeOrderPrice"=>"Jami",
    "honeOrderDelivery"=>"Yetkazib berish",
    "honeOrderButton"=>"Buyurtma",

    "footerAddress"=>"Manzil",

    "homePlaceholderInputName"=>"Ism",
    "homeContactPhone"=>"Telefon",
    "honeOrderPrice"=>"Jami",
];
return $arr;
