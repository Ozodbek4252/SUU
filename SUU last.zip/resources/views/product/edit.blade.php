@extends('layouts.app')

@section('content')
    <div class="card">
        <div class="card-body">
            @error('image')<span style="color: red;">{{$message}}</span>@enderror
            <form action="{{route('product.update', [app()->getLocale(), $product->id] )}}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                @method('PUT')
                <h1>Product</h1>
                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Name_uz</label>
                        <input type="text" class="form-control" id="category_add" name="name_uz" placeholder="Add category ..." value="{{$product->name_uz}}">
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Name_ru</label>
                        <input type="text" class="form-control" id="category_add" name="name_ru" placeholder="Add category ..." value="{{$product->name_ru}}">
                    </div>
                    <div class="" style="width: 80%; padding-right: 5px;" >
                        <label for="category_add">Name_en</label>
                        <input type="text" class="form-control" id="category_add" name="name_en" placeholder="Add category ..." value="{{$product->name_en}}">
                    </div>
                </div>



                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Photo</label>
                        {{-- <img src=""> --}}
                        <input type="file" class="form-control" id="category_add" name="image" value="fghfgh">
                    </div>
                    <div class="form-group" style="width: 80%; padding-left: 5px">
                        <label for="exampleInputEmail1">SIZE</label>
                        <select name="size" id="" class="form-control">
                            <option @if($product->size=='0.5') selected @endif value="">0.5L</option>
                            <option @if($product->size=='1') selected @endif value="">1L</option>
                            <option @if($product->size=='1.5') selected @endif value="">1.5L</option>
                            <option @if($product->size=='18.9') selected @endif value="">18.9L</option>
                        </select>
                    </div>
                    <div class="form-group" style="width: 80%; padding-right: 5px;">
                        <label for="exampleInputEmail1">Category_id</label>
                        <select name="category_id" id="" class="form-control">
                            @foreach($categories as $category)
                            <option @if($category->id==$product->category_id) selected @endif value="">{{$category->name_uz}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Description UZ</label>
                        <textarea class="form-control" id="category_add" name="description_uz" placeholder="Add description ..." >{{$product->description_uz}}</textarea>
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Description RU</label>
                        <textarea class="form-control" id="category_add" name="description_ru" placeholder="Add description ...">{{$product->description_ru}}</textarea>
                    </div>
                    <div class="" style="width: 80%; padding-right: 5px;" >
                        <label for="category_add">Description EN</label>
                        <textarea class="form-control" id="category_add" name="description_en" placeholder="Add description ...">{{$product->description_en}}</textarea>
                    </div>
                </div>

                <div class="" style="width: 25%;" >
                    <label for="category_add">Price</label>
                    <input type="text" class="form-control" id="category_add" name="price" value="{{$product->price}}">
                </div>


                <div><button type="submit" class="btn btn-primary" style="margin: 10px 10px 15px 20px">Submit</button></div>
            </form>
        </div>
    </div>


@endsection
