<script src="{{asset('/adminAssets/js/jquery-3.5.1.min.js')}}"></script>
<!-- Bootstrap js-->
<script src="{{asset('/adminAssets/js/bootstrap/popper.min.js')}}"></script>
<script src="{{asset('/adminAssets/js/bootstrap/bootstrap.js')}}"></script>
<!-- feather icon js-->
<script src="{{asset('/adminAssets/js/icons/feather-icon/feather.min.js')}}"></script>
<script src="{{asset('/adminAssets/js/icons/feather-icon/feather-icon.js')}}"></script>
<!-- Sidebar jquery-->
<script src="{{asset('/adminAssets/js/config.js')}}"></script>
<!-- Plugins JS start-->
@yield('script')
<!-- Plugins JS Ends-->
<!-- Theme js-->
<script src="{{asset('/adminAssets/js/script.js')}}"></script>
<!-- Plugin used-->
