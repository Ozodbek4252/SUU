<?php return array (
  'index' => 'App\\Http\\Livewire\\Index',
  'index-part' => 'App\\Http\\Livewire\\IndexPart',
  'order-product' => 'App\\Http\\Livewire\\OrderProduct',
  'side-basket' => 'App\\Http\\Livewire\\SideBasket',
);