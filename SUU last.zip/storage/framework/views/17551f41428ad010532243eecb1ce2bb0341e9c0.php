<div class="vertical-menu">

    <!-- LOGO -->
    <div class="navbar-brand-box">
        <a href="/" class="logo logo-dark">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.application-mark','data' => ['class' => 'w-25 mt-3']]); ?>
<?php $component->withName('jet-application-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-25 mt-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </a>

        
        
        
    </div>

    <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect vertical-menu-btn">
        <i class="fa fa-fw fa-bars"></i>
    </button>

    <div data-simplebar class="sidebar-menu-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>
                <li>
                    <a style="color: #7b8190 !important; " href="javascript: void(0);" class="has-arrow waves-effect">
                        <i  style="color: #7b8190 !important; " class="uil-water-glass"></i>
                        <span>Продукты</span>
                    </a>
                    <ul class="sub-menu">
                        <li><a style="color: #7b8190 !important; " href="<?php echo e(route('product.create', app()->getLocale())); ?>">Добавить</a></li>
                        <li><a style="color: #7b8190 !important; " href="<?php echo e(route('product.list', app()->getLocale())); ?>">Лист</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('invoice', app()->getLocale())); ?>" >
                        <i class="uil-shopping-basket"></i>
                        <span>Заказы</span>
                    </a>
                </li>
                <li>
                    <a style="color: #7b8190 !important; " href="<?php echo e(route('message', app()->getLocale())); ?>" >
                        <i  style="color: #7b8190 !important; " class="uil-envelope-alt"></i>
                        <span>Сообшении</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('news', app()->getLocale())); ?>" >
                        <i class="uil-water-glass"></i>
                        <span>News</span>
                    </a>
                </li>
            </ul>

        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH C:\wamp64\www\SUU\resources\views/layouts/simple/sidebar.blade.php ENDPATH**/ ?>