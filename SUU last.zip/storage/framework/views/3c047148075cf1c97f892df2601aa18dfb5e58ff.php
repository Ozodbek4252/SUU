

<?php $__env->startSection('content'); ?>

    <!-- /.card-header -->
        <!-- form start -->
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('product.store', app()->getLocale() )); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <h1>Category</h1>
                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="form-group" style="width: 80%; padding-right: 5px;">
                        <label for="exampleInputEmail1">Category name</label>
                        <select name="cat_name" id="" class="form-control">
                            <option value="<?php echo e(null); ?>">Select</option>
                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name_uz); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Name Uz</label>
                        <input type="text" class="form-control" id="category_add" name="cat_name_uz" placeholder="Add category ...">
                    </div>
                    <div class="" style="width: 80%; padding-right: 5px; padding-left:5px" >
                        <label for="category_add">Name Ru</label>
                        <input type="text" class="form-control" id="category_add" name="cat_name_ru" placeholder="Add category ...">
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Name En</label>
                        <input type="text" class="form-control" id="category_add" name="cat_name_en" placeholder="Add category ...">
                    </div>

                    <input name="btn" value="Saqlash" class="bg-primary" style=" height: 37px; font-size: 16px; color: #fff; border: none; border-radius: 5px;"  type="submit">
                    <input name="btn" value="Delete" class="bg-danger" style=" height: 37px; font-size: 16px; color: #fff; border: none; border-radius: 5px;"  type="submit">
                </div>
            </form>
        </div>

        <div class="card-body">

            <?php if($product != null): ?>
                <form action="<?php echo e(route('product.store', [app()->getLocale(), $product->id] )); ?>" method="post" enctype="multipart/form-data">
            <?php else: ?>
                <form action="<?php echo e(route('product.store', app()->getLocale())); ?>" method="post" enctype="multipart/form-data">
            <?php endif; ?>
                <?php echo e(csrf_field()); ?>

                <h1>Product</h1>
                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Name_uz</label>
                        <?php if($product != null): ?>
                            <input type="text" value="<?php echo e($product->name_uz); ?>" class="form-control" id="category_add" name="name_uz" placeholder="Add Name Uz...">
                        <?php else: ?>
                            <input type="text" class="form-control" id="category_add" name="name_uz" placeholder="Add Name Uz...">
                        <?php endif; ?>
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Name_ru</label>
                        <?php if($product != null): ?>
                            <input type="text" value="<?php echo e($product->name_ru); ?>"  class="form-control" id="category_add" name="name_ru" placeholder="Add Name_ru...">
                            <?php else: ?>
                            <input type="text" class="form-control" id="category_add" name="name_ru" placeholder="Add Name_ru...">
                        <?php endif; ?>
                    </div>
                    <div class="" style="width: 80%; padding-right: 5px;" >
                        <label for="category_add">Name_en</label>
                        <?php if($product != null): ?>
                            <input type="text" value="<?php echo e($product->name_en); ?>" class="form-control" id="category_add" name="name_en" placeholder="Add Name_en...">
                            <?php else: ?>
                            <input type="text" class="form-control" id="category_add" name="name_en" placeholder="Add Name_en...">
                        <?php endif; ?>
                    </div>

                </div>


                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Photo</label>
                        <?php if($product != null): ?>
                            <input type="file" value="<?php echo e($product->name_en); ?>" class="form-control" id="category_add" name="image">
                            <?php else: ?>
                            <input type="file" class="form-control" id="category_add" name="image">
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="width: 80%; padding-left: 5px">
                        <label for="exampleInputEmail1">SIZE</label>
                        <?php if($product != null): ?>
                            <select name="size" id="" class="form-control">
                                <option value="<?php echo e(null); ?>" >Select</option>
                                <option <?php if($product->size == "0.5"): ?> selected <?php endif; ?> value="0.5" >0.5L</option>
                                <option <?php if($product->size == "1"): ?> selected <?php endif; ?> value="1" >1L</option>
                                <option <?php if($product->size == "1.5"): ?> selected <?php endif; ?> value="1.5" >1.5L</option>
                                <option <?php if($product->size == "15"): ?> selected <?php endif; ?> value="15" >15L</option>
                            </select>
                        <?php else: ?>
                            <select name="size" id="" class="form-control">
                                <option value="<?php echo e(null); ?>" >Select</option>
                                <option value="0.5" >0.5L</option>
                                <option value="1" >1L</option>
                                <option value="1.5" >1.5L</option>
                                <option value="18.9" >18.9L</option>
                            </select>
                        <?php endif; ?>
                    </div>
                    <div class="form-group" style="width: 80%; padding-right: 5px; padding-left: 5px">
                        <label for="exampleInputEmail1">Category_id</label>
                        <select name="cat_id" id="" class="form-control" >
                            <option value="<?php echo e(null); ?>" >Select</option>
                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($product != null): ?> <?php if($product->cat_id == $product_category->id): ?> selected <?php endif; ?> <?php endif; ?> value="<?php echo e($product_category->id); ?>"><?php echo e($product_category->name_uz); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Description UZ</label>
                        <?php if($product != null): ?>
                            <textarea class="form-control" id="category_add" name="description_uz" placeholder="Add description ..."><?php echo e($product->description_uz); ?></textarea>
                        <?php else: ?>
                            <textarea class="form-control" id="category_add" name="description_uz" placeholder="Add description ..."></textarea>
                        <?php endif; ?>
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Description RU</label>
                        <?php if($product != null): ?>
                            <textarea class="form-control" id="category_add" name="description_ru" placeholder="Add description ..."><?php echo e($product->description_ru); ?></textarea>
                        <?php else: ?>
                            <textarea class="form-control" id="category_add" name="description_ru" placeholder="Add description ..."></textarea>
                        <?php endif; ?>
                    </div>
                    <div class="" style="width: 80%; padding-right: 5px;" >
                        <label for="category_add">Description EN</label>
                        <?php if($product != null): ?>
                            <textarea class="form-control" id="category_add" name="description_en" placeholder="Add description ..."><?php echo e($product->description_en); ?></textarea>
                        <?php else: ?>
                            <textarea class="form-control" id="category_add" name="description_en" placeholder="Add description ..."></textarea>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="" style="width: 25%;" >
                    <label for="category_add">Price</label>
                    <?php if($product != null): ?>
                        <input value="<?php echo e($product->price); ?>" type="text" class="form-control" id="category_add" name="price" placeholder="Add price ...">
                        <?php else: ?>
                        <input type="text" class="form-control" id="category_add" name="price" placeholder="Add price ...">
                    <?php endif; ?>
                </div>

                <div>
                    <button type="submit" class="btn btn-primary" style="margin: 10px 10px 15px 20px">Submit</button>
                </div>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU\resources\views/product/create.blade.php ENDPATH**/ ?>