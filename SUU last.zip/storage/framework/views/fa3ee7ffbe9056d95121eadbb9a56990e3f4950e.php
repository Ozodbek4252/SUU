<?php echo $__env->yieldContent('css'); ?>
<!-- Bootstrap Css -->
<link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(asset('assets/css/app.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

<?php /**PATH C:\wamp64\www\SUU dash\resources\views/layouts/simple/css.blade.php ENDPATH**/ ?>