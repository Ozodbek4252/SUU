<?php  $price = 0; ?>
<?php $__currentLoopData = session()->get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $price += \App\Models\Product::find($key)->price;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($price); ?><span>UZS</span>
<?php /**PATH /var/www/u1056610/public_html/suu.u1056610.cp.regruhosting.ru/resources/views/front/price.blade.php ENDPATH**/ ?>