

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Invoices</h4>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        </tr>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>User</th>
                            <th>Sum</th>
                            <th>Delivery</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $num=1; ?>
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($num++); ?></td>
                            <td><a href="<?php echo e(route('dash.orders', [app()->getLocale(), $invoice->id])); ?>"><?php echo e($invoice->name); ?></a></td>
                            <td>
                                <?php if($invoice->message): ?>
                                    <ul style="list-style: none; padding-left: 0;">
                                        <li>Name: <?php echo e($invoice->message->name); ?></li>
                                        <li>Phone: <a href="tel:<?php echo e($invoice->message->phone); ?>"><?php echo e($invoice->message->phone); ?></a></li>
                                    </ul>
                                <?php else: ?> 
                                    Eski 
                                <?php endif; ?></td>
                            </td>
                            <td><?php echo e($invoice->sum); ?></td>
                            <td><?php echo e($invoice->delivery); ?></td>
                            <td><?php echo e($invoice->updated_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($invoices->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU last\resources\views/invoice/index.blade.php ENDPATH**/ ?>