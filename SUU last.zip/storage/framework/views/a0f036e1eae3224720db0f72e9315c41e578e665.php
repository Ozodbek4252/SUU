<div class="side-basket">
    
    <div class="feedback-content">
        <div class="side-basket__content">
            <?php if(session()->get('cart')): ?>
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="side-basket__item">
                        <div class="cabinet-order__img">
                            <img src="img/water1.png" alt="img">
                        </div>
                        <div class="cabinet-order__name">
                            Негазированная <span>(1.5)</span>
                            <?php echo e($item['id']); ?>

                            <?php echo e($b); ?>

                        </div>
                        <div wire:click="deleteItem(<?php echo e($item['id']); ?>)" class="basket-item__delete">
                            <img src="img/del.svg" alt="ico">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="side-basket__price">
            <div class="order-price">
                <div class="order-price__item">
                    <span class="order-price__name">Промежуточный итог</span>
                    <span class="order-price__value">42000 <span>UZS</span></span>
                </div>
                <div class="order-price__item">
                    <span class="order-price__name">Доставка</span>
                    <span class="order-price__value">0 <span>UZS</span></span>
                </div>
            </div>
            <button class="order-add btn">
                Оплатить
            </button>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\SUU\resources\views/livewire/side-basket.blade.php ENDPATH**/ ?>