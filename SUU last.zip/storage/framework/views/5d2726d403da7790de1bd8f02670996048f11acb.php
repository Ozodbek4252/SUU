

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <h1>Invoices</h1>

            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            

            

            <table style="font-family: arial, sans-serif; border-collapse: collapse; width: 100%; margin-top: 10px" >
                <tr class="categoryShow">
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">#</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Name</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Delivery</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Sum</th>
                    
                </tr>
                <?php $num=1; ?>
                <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="categoryShow">
                        <td ><?php echo e($num++); ?></td>
                        <td ><a href="<?php echo e(route('dash.orders', [app()->getLocale(), $invoice->id])); ?>"><?php echo e($invoice->name); ?></a></td>
                        <td><?php echo e($invoice->delivery); ?></td>
                        <td><?php echo e($invoice->sum); ?></td>
                        <td></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU\resources\views/invoice/index.blade.php ENDPATH**/ ?>