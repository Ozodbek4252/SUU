

<?php $__env->startSection('content'); ?>

	<!-- ОБРАТНАЯ СВЯЗЬ -->

	<div class="popup-layer"></div>


	<!-- АВТОРИЗАЦИЯ -->
	<?php
		session()->put('locale', Request::segment(1))
	?>
	<div class="login">
		<div class="feedback-content">
			<div class="feedback__title">
				<?php echo e(__('Зарегистрироваться')); ?>

			</div>
			<div class="feedback__text">
				<?php echo e(__('homeInputTitleText')); ?> <strong>suu.uzbekistan</strong>
			</div>
			<div class="feedback-form">
				<div class="feedback-date">
					<select id="dobday"></select>
					<select id="dobmonth"></select>
					<select id="dobyear"></select>
				</div>
				<input type="text" placeholder="Имя">
				<input type="text" placeholder="Фамилия">
				<input type="email" placeholder="Ваш электронный адрес">
				<p><?php echo e(__('Пароль')); ?></p>
				<input type="password" placeholder="Новый пароль">
				<input type="password" placeholder="Подтвердите пароль">
				<div class="feedback-form__check">
					<label>
						<input type="checkbox">
						<span><?php echo e(__('homeInputChech')); ?></span>
					</label>
				</div>
				<button type="submit" class="btn"><?php echo e(__('homeInputButton')); ?></button>
			</div>
		</div>
	</div>


	<!-- МОБИЛЬНОЕ МЕНЮ -->
	<div class="mobile-menu">
		<div class="mobile-menu__head">
			<div class="mobile-menu__logo">
				<a href="index.blade.php">
					<img src="img/logo.svg" alt="SUU" title="SUU">
				</a>
			</div>
			<div class="mobile-menu__close">
				<div class="header-mobile header-mobile__open">
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
		</div>
		<ul class="menu">
			<li>
				<a href="/home" data-menuanchor="main">
					<?php echo e(__('navHome')); ?>

				</a>
			</li>
			<li>
				<a href="#about" data-menuanchor="about">
					<?php echo e(__('aboutTitle')); ?>

				</a>
			</li>
			<li>
				<a href="#products" data-menuanchor="products">
					<?php echo e(__('homeProductTitle')); ?>

				</a>
			</li>
			<li>
				<a href="#services" data-menuanchor="services">
					<?php echo e(__('homeServiceTitle')); ?>

				</a>
			</li>
			<li>
				<a href="#news" data-menuanchor="news">
					<?php echo e(__('homeNewsTitle')); ?>

				</a>
			</li>
			<li>
				<a href="#contact" data-menuanchor="contact">
					<?php echo e(__('homeContactTitle')); ?>

				</a>
			</li>
		</ul>
		<ul class="side__follow">
			<li>
				<a href="#" target="_blank" rel="_nofollow">
					<img src="img/fb.svg" alt="Facebook">
				</a>
			</li>
			<li>
				<a href="#" target="_blank" rel="_nofollow">
					<img src="img/inst.svg" alt="Instagram">
				</a>
			</li>
			<li>
				<a href="#" target="_blank" rel="_nofollow">
					<img src="img/tg.svg" alt="Telegram">
				</a>
			</li>
		</ul>
		<div class="mobile-menu__lang">
			<a href="#">РУ</a>
			<a href="#">UZ</a>
			<a href="#">EN</a>
		</div>
	</div>


	<!-- ХЭДЕР СТАТИЧЕСКИЙ, ОТЛИЧАЕТСЯ ОТ ГЛАВНОГО -->




	<!-- КОРЗИНА -->
    <form action=""></form>

	<section class="basket">
		<div class="container" id="basket_refresh">
			<div class="basket-empty">
                <?php if(!session()->get('cart')): ?>
                    <?php echo e(__('ВАША КОРЗИНА ПУСТА')); ?>

                <?php endif; ?>
			</div>

			<div class="basket-list" id="basket-list">
                <?php $total_price = 0 ?>
                <?php if(session()->get('cart') != null): ?>
                    <?php $__currentLoopData = session()->get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cart = session()->get('cart');
                            $product = \App\Models\Product::find($key);
                            $total_price += $product->price*$cart[$key]['quantity'];
                        ?>
						
                        <div class="basket-item" id="basket-item<?php echo e($product->id); ?>">
                            <div class="basket-item__delete" onclick="deleteProduct(<?php echo e($product->id); ?>)">
                                <img src="img/del.svg" alt="ico">
                            </div>
                            <div class="basket-item__img">
                                <img src="<?php echo e($product->image_path); ?>/<?php echo e($product->image); ?>" alt="img">
                            </div>
                            <div class="basket-item__wrap">
                                <div class="basket-item__size" id="basket-item__size'+i+'">
                                    <?php if($product->category_id != 3): ?>
                                        <?php echo e($product->price/6); ?>

                                    <?php else: ?>
                                        <?php echo e($product->price); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="basket-item__info">
                                    <div class="basket-item__head">
                                        <h2 class="basket-item__name">
                                            <?php echo e(\App\Models\Category::find($product->category_id)['name_'.app()->getLocale()]); ?> (<?php echo e($product->size); ?>L)
                                        </h2>
                                        <div class="basket-item__price"><?php echo e(__('cartPrice')); ?>

                                            <span>
                                                <strong id="price_product"><?php echo e($product->price*$cart[$key]['quantity']); ?></strong> UZS
                                            </span>
                                        </div>
                                    </div>
								
                                    <div class="basket-item__text">
                                        <?php echo e($product['description_'.app()->getLocale()]); ?>

                                    </div>
                                    <div class="basket-item__logo btn">
                                        <span>
                                            <?php if($cart[$key]['logo'] == '0'): ?>
                                                <?php echo e(__('Без логотипа')); ?>

                                            <?php else: ?>
                                                <?php echo e(__('С вашим логотипом')); ?>

                                            <?php endif; ?>
                                        </span>
                                        <svg width="11" height="11" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M9.41619 1.17401L5.29546 5.29474M1.17473 9.41547L5.29546 5.29474M5.29546 5.29474L9.26077 9.26005L1.12145 1.12073" stroke="#217BBE" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </div>
                                    <div class="basket-item__total">
                                            <div><?php if($product->category_id != 3): ?> 6 x <?php echo e($product->price/6); ?> = <?php endif; ?></div>
                                        <div>
                                            <strong><?php echo e($product->price); ?></strong> UZS * <span>
                                                <?php echo e($cart[$key]['quantity']); ?> <?php if($product->category_id != 3): ?> блок <?php else: ?> капсула <?php endif; ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="basket-item__open">
                                        <?php echo e(__('количество')); ?>

                                        <svg width="15" height="9" viewBox="0 0 15 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M14 1L7.5 7L1 1" stroke="#217BBE" stroke-width="1.5" stroke-linecap="round"/>
                                        </svg>
                                    </div>
                                    <div class="basket-item__dropdown">
                                        <div class="order-thin">
                                            <div class="order-item order-count">
                                                <div class="order-item__title">
                                                    <?php echo e(__('Выберите количество блоков')); ?>

                                                </div>
                                                <select id="blok_quantity<?php echo e($product->id); ?>" onchange="quantity(<?php echo e($product->id); ?>)">
                                                    <?php for($i=1; $i<5; $i++): ?>
                                                        <option value="<?php echo e($i); ?>" <?php if($cart[$key]['quantity'] == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                            <div class="order-item order-print">
                                                <div class="order-item__title">
                                                    <?php echo e(__('Печать логотипа')); ?>

                                                </div>
                                                <div class="order-print__btns">
                                                    <button class="btn <?php if($cart[$key]['logo'] == 1): ?> active <?php endif; ?>" onclick="logo(1, <?php echo e($product->id); ?>)"><?php echo e(__('С вашим логотипом')); ?></button>
                                                    <button class="btn <?php if($cart[$key]['logo'] == 0): ?> active <?php endif; ?>" onclick="logo(0, <?php echo e($product->id); ?>)"><?php echo e(__('Без логотипа')); ?></button>
                                                </div>
                                                <div class="order-print__images">
                                                    <div>
                                                        <img src="img/print1.png" alt="img">
                                                    </div>
                                                    <div>
                                                        <img src="img/print2.png" alt="img">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="order-price">
                                                <div class="order-price__item">
                                                    <span class="order-price__name"><?php echo e(__('honeOrderPrice')); ?></span>
                                                    <span class="order-price__value" id="order-price__name'+i+'"><?php echo e($product->price*$cart[$key]['quantity']); ?><span>UZS</span></span>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
			</div>
            <?php if(session()->get('cart')): ?>
            <div class="basket-content" id="basket-content">
              <form action="<?php echo e(Route('order.create', app()->getLocale())); ?>" class="basket-form">
                <div class="basket-form__title">
                  <?php echo e(__('cartFormTitle')); ?>

                </div>
                <select name="status" class="basket-form__select">
                  <option value="new" selected><?php echo e(__('cartFormOption1')); ?></option>
                  <option value="constant"><?php echo e(__('cartFormOption2')); ?></option>
                </select>
                <div class="form-half">
                  <input name="name" type="text" placeholder="<?php echo e(__('homePlaceholderInputName')); ?>">
                  <input name="phone" type="tel" placeholder="<?php echo e(__('homeContactPhone')); ?>" class="form__tel" maxlength="19" required="" pattern="^[0-9-+\s()]*$">
                </div>
                <div class="order-item order-delivery">
                  <div class="order-item__title">
                    <?php echo e(__('honeOrderDelivery')); ?>

                  </div>

                  <div class="order-delivery__btns">
                    <button name="deliveryNeeded" class="btn active" type="button"><?php echo e(__('cartFormDelivery1')); ?></button>
                    <button name="deliveryNoNeed" class="btn" type="button"><?php echo e(__('cartFormDelivery2')); ?></button>
                  </div>
                </div>
                <div class="basket-form__price">
                  <span><?php echo e(__('honeOrderPrice')); ?></span>
                  <span></span>
                  <span><strong id="total_price"><?php echo e($total_price); ?></strong> UZS</span>
                </div>
                <div class="basket-form__price">
                  <span><?php echo e(__('honeOrderDelivery')); ?></span>
                  <span></span>
                  <span><strong>00</strong> UZS</span>
                </div>
                <div class="basket-form__choose">
                  <div>
                    <input type="radio" name="pay" id="cash"> <label for="cash"><?php echo e(__('cartFormPaymentM1')); ?></label>
                  </div>
                  <div>
                    <input type="radio" name="pay" id="card"> <label for="card"><?php echo e(__('cartFormPaymentM2')); ?></label>
                  </div>
                </div>
                <div class="basket-form__cards">
                  <div class="basket-form__card active">
                    <img src="img/click.png" alt="ico">
                  </div>
                  <div class="basket-form__card">
                    <img src="img/payme.png" alt="ico">
                  </div>
                  <div class="basket-form__card">
                    <img src="img/upay.png" alt="ico">
                  </div>
                  <div class="basket-form__card">
                    <img src="img/paynet.png" alt="ico">
                  </div>
                  <div class="basket-form__card">
                    <img src="img/apelsin.png" alt="ico">
                  </div>
                </div>
                <button type="submit" class="order-add btn">
                  <?php echo e(__('cartFormPayBtn')); ?>

                </button>
              </form>
              <div class="basket-info">
                <div class="basket-info__title">
                  <?php echo e(__('cartReqTitle')); ?>

                </div>
                <ul class="basket-info__list">
                  <li>
                    <span><?php echo e(__('cartReqResip')); ?>:</span> OOO “SUU Tashkent”
                  </li>
                  <li>
                    <span><?php echo e(__('footerAddress')); ?>:</span> <?php echo e(__('cartReqAddress')); ?>

                  </li>
                  <li>
                    <span><?php echo e(__('cartReqTIN')); ?>:</span> 7706412841
                  </li>
                  <li>
                    <span><?php echo e(__('cartReqBC')); ?>:</span> <?php echo e(__('cartReqBCBody')); ?>

                  </li>
                  <li>
                    <span><?php echo e(__('cartReqIFI')); ?>:</span> 01075
                  </li>
                  <li>
                    <span><?php echo e(__('cartReqTIN')); ?>:</span> 306 164 875
                  </li>
                  <li>
                    <span><?php echo e(__('cartReqNCKEA')); ?>:</span> 58290
                  </li>
                </ul>
              </div>
            </div>
            <?php endif; ?>
		</div>
	</section>
	
	


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU dash\resources\views/front/basket.blade.php ENDPATH**/ ?>