<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="footer-bottle">
                <img src="img/footer.png" alt="bottle">
            </div>
            <div class="footer-logo">
                <img src="img/logo.svg" alt="SUU">
                <span><?php echo e(__('footerTitle')); ?></span>
            </div>
            <ul class="footer-menu">
                <li>
                    <a href="<?php echo e(route('home', app()->getLocale())); ?>"><?php echo e(__('navHome')); ?></a>
                </li>
                <li>
                    <a href="<?php echo e(route('about', app()->getLocale())); ?>"><?php echo e(__('navAbout')); ?></a>
                </li>
                <li>
                    <a href="<?php echo e(route('about', app()->getLocale())); ?>"><?php echo e(__('navProducts')); ?></a>
                </li>
                <li>
                    <a href="#"><?php echo e(__('navServices')); ?></a>
                </li>
                <li>
                    <a href="<?php echo e(route('front.news', app()->getLocale())); ?>"><?php echo e(__('navNews')); ?></a>
                </li>
                <li>
                    <a href="#"><?php echo e(__('navContact')); ?></a>
                </li>
            </ul>
            <div class="footer-info">
                <div class="footer-info__item">
                    <div class="footer-info__name">
                        <?php echo e(__('footerAddress')); ?>:
                    </div>
                    <div class="footer-info__value">
                        <?php echo e(__('footerAddressInfo')); ?>

                    </div>
                </div>
                <div class="footer-info__item">
                    <div class="footer-info__name">
                        <?php echo e(__('footerPhone')); ?>:
                    </div>
                    <div class="footer-info__value">
                        <a href="tel:+998911521915">+99891 152 19 15</a>
                    </div>
                </div>
                <div class="footer-info__item">
                    <div class="footer-info__name">
                        <?php echo e(__('footerMail')); ?>:
                    </div>
                    <div class="footer-info__value">
                        <a href="mailto:info@suuuzbekistan.uz">info@suuuzbekistan.uz</a>
                    </div>
                </div>
                <div class="footer-info__item">
                    <div class="footer-info__name">
                        <?php echo e(__('footerSocial')); ?>:
                    </div>
                    <div class="footer-info__value">
                        <ul>
                            <li>
                                <a href="#" target="_blank" rel="_nofollow">
                                    <img src="img/fb.svg" alt="Facebook">
                                </a>
                            </li>
                            <li>
                                <a href="#" target="_blank" rel="_nofollow">
                                    <img src="img/inst.svg" alt="Instagram">
                                </a>
                            </li>
                            <li>
                                <a href="#" target="_blank" rel="_nofollow">
                                    <img src="img/tg.svg" alt="Telegram">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-copy">
        <div class="container">
            <p>
                &copy; 2021 «SUU.UZBEKISTAN»
            </p>
            <p>
                Designed by <a href="#" target="_blank">Novas.uz</a>
            </p>
        </div>
    </div>
</footer>
<?php /**PATH /var/www/u1056610/public_html/suu.u1056610.cp.regruhosting.ru/resources/views/front/component/footer.blade.php ENDPATH**/ ?>