<?php $__currentLoopData = session()->get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $product = \App\Models\Product::find($key);
    ?>
    <div class="side-basket__item">
        <div class="cabinet-order__img">
            <img src="<?php echo e($product->image_path); ?>/<?php echo e($product->image); ?>" alt="img">
        </div>
        <div class="cabinet-order__name"><?php echo e(\App\Models\Category::find($product->category_id)['name_'.session()->get('locale')]); ?>(<?php echo e($product->size); ?> L)
            <br> <span><?php echo e($product->price); ?> UZS</span>
        </div>
        <div class="basket-item__delete" onclick="deleteProduct(<?php echo e($product->id); ?>)">
            <img src="img/del.svg" alt="ico">
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH /var/www/u1056610/public_html/suu.u1056610.cp.regruhosting.ru/resources/views/front/cart.blade.php ENDPATH**/ ?>