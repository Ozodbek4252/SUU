<?php
$k = 0;
foreach(session()->get('cart') as $key=>$value){
    $k++;
}
?><?php echo e($k); ?>

<?php /**PATH /var/www/u1056610/public_html/suu.u1056610.cp.regruhosting.ru/resources/views/front/quantity_product.blade.php ENDPATH**/ ?>