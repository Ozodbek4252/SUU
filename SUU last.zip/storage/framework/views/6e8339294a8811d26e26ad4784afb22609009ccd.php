

<?php $__env->startSection('content'); ?>
	<!-- ОБРАТНАЯ СВЯЗЬ -->
	<div class="popup-layer"></div>

	<!-- МОБИЛЬНОЕ МЕНЮ -->
	<div class="mobile-menu">
		<div class="mobile-menu__head">
			<div class="mobile-menu__logo">
				<a href="index.blade.php">
					<img src="img/logo.svg" alt="SUU" title="SUU">
				</a>
			</div>
			<div class="mobile-menu__close">
				<div class="header-mobile header-mobile__open">
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
		</div>
		<ul class="menu">
			<li>
				<a href="<?php echo e(route('home', app()->getLocale())); ?>">
					<?php echo e(__('navHome')); ?>

				</a>
			</li>
			<li>
				<a href="<?php echo e(route('about', app()->getLocale())); ?>">
					<?php echo e(__('navAbout')); ?>

				</a>
			</li>
			<li>
				<a href="/">
					<?php echo e(__('navProducts')); ?>

				</a>
			</li>
			<li>
				<a href="/">
					<?php echo e(__('navServices')); ?>

				</a>
			</li>
			<li>
				<a href="<?php echo e(route('front.news', app()->getLocale())); ?>">
					<?php echo e(__('navNews')); ?>

				</a>
			</li>
			<li>
				<a href="/">
					<?php echo e(__('navContact')); ?>

				</a>
				
			</li>
		</ul>
		<ul class="side__follow">
			<li>
				<a href="#" target="_blank" rel="_nofollow">
					<img src="img/fb.svg" alt="Facebook">
				</a>
			</li>
			<li>
				<a href="#" target="_blank" rel="_nofollow">
					<img src="img/inst.svg" alt="Instagram">
				</a>
			</li>
			<li>
				<a href="#" target="_blank" rel="_nofollow">
					<img src="img/tg.svg" alt="Telegram">
				</a>
			</li>
		</ul>
		<div class="mobile-menu__lang">
			<a href="<?php echo e(route(Route::currentRouteName(), ['ru', \Request::segment(3)])); ?>">
				РУ
			</a>
			<a href="<?php echo e(route(Route::currentRouteName(), ['uz', \Request::segment(3)])); ?>">
				UZ
			</a>
			<a href="<?php echo e(route(Route::currentRouteName(), ['en', \Request::segment(3)])); ?>">
				EN
			</a>
		</div>
	</div>

	<!-- НОВОСТИ -->
	<section class="news-main">
		<div class="container">
			<div class="news-main__content">
				<h1 class="news__title section__title">
					<?php echo e(__('homeNewsTitle')); ?>

				</h1>
				<div class="news__text section__text">
					<?php echo e(__('newsTitleText')); ?>

				</div>
			</div>
			<?php 
			$load = session()->get('load') ;
			$load['load'] = 3;
			?>
			<div id="news-wrap">
				<div class="news-wrap">
					<?php $__currentLoopData = App\Models\News::orderBy('id', 'desc')->take($load['load'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="news-carousel__item">
							<div class="news-carousel__img">
								<img src="<?php echo e($news->image_path); ?>/<?php echo e($news->image); ?>" alt="news">
							</div>
							<div class="news-carousel__text">
								<?php if(app()->getLocale()=='uz'): ?>
									<?php echo e($news->name_uz); ?>

								<?php elseif(app()->getLocale()=='ru'): ?>
									<?php echo e($news->name_ru); ?>

								<?php elseif(app()->getLocale()=='en'): ?>
									<?php echo e($news->name_en); ?>

								<?php else: ?>
								<?php endif; ?>
							</div>
							<div class="news-carousel__info">
								<span>
									<?php echo e(explode(".", $news->updated_at->format('d.m.Y'))[0].'.'
									.$months[explode(".", $news->updated_at->format('d.m.Y'))[1]].'.'.
									explode(".", $news->updated_at->format('d.m.Y'))[2]); ?>

								</span>
								<span><img src="img/eye-gray.svg" alt="ico"><?php echo e($news->view); ?></span>
							</div>
							<a href="<?php echo e(route('single-news', [app()->getLocale(), $news->id] )); ?>"></a>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="news-more">
					<a onclick="load(<?php echo e($load['load']); ?>)">
						<img src="img/more.svg" alt="ico">
						<?php echo e(__('newsButton')); ?>

					</a>
				</div>
			</div>
		</div>
	</section>
	<script>
		function load($q){
			$k = $q+3;
			console.log($k);
			$.ajax({
				type: 'get',
				url:'/load/'+$k,
				dataType: 'json',
				success: function(){
					$("#news-wrap").load('/load');
				}
			});
		}
	</script>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU last\resources\views/front/news.blade.php ENDPATH**/ ?>