<?php
$k = 0;
foreach(session()->get('cart') as $key=>$value){
    $k++;
}
?><?php echo e($k); ?>

<?php /**PATH C:\wamp64\www\SUU last\resources\views/front/quantity_product.blade.php ENDPATH**/ ?>