

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <h1>Invoices</h1>

            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            

            

            <table class="table" style="font-family: arial, sans-serif; border-collapse: collapse; width: 100%; margin-top: 10px" >
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr class="categoryShow">
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px; width: 3%;">#</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Name</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">User</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Sum</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px; width: 10%;">Delivery</th>
                    
                </tr>
                </thead>
                <tbody>
                <?php $num=1; ?>
                <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="categoryShow">
                        <td style="text-align: center;"><?php echo e($num++); ?></td>
                        <td style="padding-left: 10px;"><a href="<?php echo e(route('dash.orders', [app()->getLocale(), $invoice->id])); ?>"><?php echo e($invoice->name); ?></a></td>
                        <td style="padding-left: 5px;"><?php if($invoice->message): ?>
                            <ul style="list-style: none; padding-left: 0;">
                                <li>Name: <?php echo e($invoice->message->name); ?></li>
                                <li>Phone: <a href="tel:<?php echo e($invoice->message->phone); ?>"><?php echo e($invoice->message->phone); ?></a></li>
                            </ul>
                            <?php else: ?> Eski <?php endif; ?></td>
                        <td><?php echo e($invoice->sum); ?></td>
                        <td><?php echo e($invoice->delivery); ?></td>
                        <td></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1056610/public_html/suu.u1056610.cp.regruhosting.ru/resources/views/invoice/index.blade.php ENDPATH**/ ?>