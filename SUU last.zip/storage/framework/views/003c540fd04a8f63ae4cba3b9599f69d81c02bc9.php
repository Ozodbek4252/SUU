<?php 
$load = session()->get('load');
?>
<div class="news-wrap">
    <?php $__currentLoopData = App\Models\News::orderBy('id', 'desc')->take($load['load'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="news-carousel__item">
            <div class="news-carousel__img">
                <img src="<?php echo e($news->image_path); ?>/<?php echo e($news->image); ?>" alt="news">
            </div>
            <div class="news-carousel__text">
                <?php if(app()->getLocale()=='uz'): ?>
                    <?php echo e($news->name_uz); ?>

                <?php elseif(app()->getLocale()=='ru'): ?>
                    <?php echo e($news->name_ru); ?>

                <?php elseif(app()->getLocale()=='en'): ?>
                    <?php echo e($news->name_en); ?>

                <?php else: ?>
                <?php endif; ?>
            </div>
            <div class="news-carousel__info">
                
                <span><img src="img/eye-gray.svg" alt="ico">20</span>
            </div>
            <a href="<?php echo e(route('single-news', [app()->getLocale(), $news->id] )); ?>"></a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="news-more">
    <a onclick="load(<?php echo e($load['load']); ?>)">
        <img src="img/more.svg" alt="ico">
        <?php echo e(__('newsButton')); ?>

    </a>
</div><?php /**PATH C:\wamp64\www\SUU last\resources\views/front/load_product.blade.php ENDPATH**/ ?>