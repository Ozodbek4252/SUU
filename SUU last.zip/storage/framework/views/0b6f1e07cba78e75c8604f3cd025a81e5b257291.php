

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Сообшении</h4>
                
                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                    </tr>
                    <tr>
                        <th>#</th>
                        <th>Invoice</th>
                        <th>Name</th>
                        <th>Last Name</th>
                        <th>Phone</th>
                        <th>Message</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $num=1; ?>
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($num++); ?></td>
                        <td><?php if($message->invoice_id): ?><a href="/"><?php echo e($message->invoice->name); ?></a><?php endif; ?></td>
                        <td><?php echo e($message->name); ?></td>
                        <td><?php echo e($message->last_name); ?></td>
                        <td><a href="tel:<?php echo e($message->phone); ?>"><?php echo e($message->phone); ?></a></td>
                        <td style="width: 35%"><?php echo e($message->message); ?></td>
                        <td><?php echo e($message->updated_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($messages->links()); ?>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU last\resources\views/message/index.blade.php ENDPATH**/ ?>