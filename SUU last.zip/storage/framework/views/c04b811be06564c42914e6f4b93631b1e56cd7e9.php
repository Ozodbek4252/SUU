

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <form action="<?php echo e(route('product.update', [app()->getLocale(), $product->id] )); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo method_field('PUT'); ?>
                <h1>Product</h1>
                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Name_uz</label>
                        <input type="text" class="form-control" id="category_add" name="name_uz" placeholder="Add category ..." value="<?php echo e($product->name_uz); ?>">
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Name_ru</label>
                        <input type="text" class="form-control" id="category_add" name="name_ru" placeholder="Add category ..." value="<?php echo e($product->name_ru); ?>">
                    </div>
                    <div class="" style="width: 80%; padding-right: 5px;" >
                        <label for="category_add">Name_en</label>
                        <input type="text" class="form-control" id="category_add" name="name_en" placeholder="Add category ..." value="<?php echo e($product->name_en); ?>">
                    </div>
                </div>



                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Photo</label>
                        
                        <input type="file" class="form-control" id="category_add" name="image" value="fghfgh">
                    </div>
                    <div class="form-group" style="width: 80%; padding-left: 5px">
                        <label for="exampleInputEmail1">SIZE</label>
                        <select name="size" id="" class="form-control">
                            <option <?php if($product->size=='0.5'): ?> selected <?php endif; ?> value="">0.5L</option>
                            <option <?php if($product->size=='1'): ?> selected <?php endif; ?> value="">1L</option>
                            <option <?php if($product->size=='1.5'): ?> selected <?php endif; ?> value="">1.5L</option>
                            <option <?php if($product->size=='18.9'): ?> selected <?php endif; ?> value="">18.9L</option>
                        </select>
                    </div>
                    <div class="form-group" style="width: 80%; padding-right: 5px;">
                        <label for="exampleInputEmail1">Category_id</label>
                        <select name="category_id" id="" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($category->id==$product->category_id): ?> selected <?php endif; ?> value=""><?php echo e($category->name_uz); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group container-fluid d-flex justify-content-between align-items-end" style="padding: 0px">
                    <div class="" style="width: 80%;" >
                        <label for="category_add">Description UZ</label>
                        <textarea class="form-control" id="category_add" name="description_uz" placeholder="Add description ..." ><?php echo e($product->description_uz); ?></textarea>
                    </div>
                    <div class="" style="width: 80%; padding: 0 5px;" >
                        <label for="category_add">Description RU</label>
                        <textarea class="form-control" id="category_add" name="description_ru" placeholder="Add description ..."><?php echo e($product->description_ru); ?></textarea>
                    </div>
                    <div class="" style="width: 80%; padding-right: 5px;" >
                        <label for="category_add">Description EN</label>
                        <textarea class="form-control" id="category_add" name="description_en" placeholder="Add description ..."><?php echo e($product->description_en); ?></textarea>
                    </div>
                </div>

                <div class="" style="width: 25%;" >
                    <label for="category_add">Price</label>
                    <input type="text" class="form-control" id="category_add" name="price" value="<?php echo e($product->price); ?>">
                </div>


                <div><button type="submit" class="btn btn-primary" style="margin: 10px 10px 15px 20px">Submit</button></div>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU last\resources\views/product/edit.blade.php ENDPATH**/ ?>