

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <h1>Orders</h1>

            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            

            

            <table style="font-family: arial, sans-serif; border-collapse: collapse; width: 100%; margin-top: 10px" >
                <tr class="categoryShow">
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">#</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px; width: 40%;">Product</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Quantity</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Logo</th>
                    
                </tr>
                <?php $num=1; ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="categoryShow">
                        <td ><?php echo e($num++); ?></td>
                        <td style="display: flex;">
                            <ul style="list-style: none; padding-left: 5px; margin-bottom: 0; margin: auto 0;">
                                <li>Name: <?php echo e($order->product->name_ru); ?></li>
                                <li>Price: <?php echo e($order->product->price); ?></li>
                                <li>Category: <?php echo e($order->product->category->name_ru); ?></li>
                            </ul>
                            <img src="<?php echo e($order->product->image_path); ?>/<?php echo e($order->product->image); ?>" alt="img" height="120" width="100" style="object-fit: contain;"/>
                        </td>
                        <td style="padding-left: 5px;"><?php echo e($order->quantity); ?></td>
                        <td style="padding-left: 5px;"><?php echo e($order->logo); ?></td>
                        
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU\resources\views/invoice/orders.blade.php ENDPATH**/ ?>