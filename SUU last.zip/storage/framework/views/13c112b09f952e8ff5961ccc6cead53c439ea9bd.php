

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <h1>News</h1>

            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div style="margin-bottom: 1rem;">
                <?php if(session()->has('message')): ?>
                    <div style="padding: .75rem; background: #9ae6b4; color: #276749; border-radius: 0.25rem; box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);" class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php elseif(session()->has('deleteMessage')): ?>
                    <div style="padding: .75rem; background: #feb2b2; color: #9b2c2c; border-radius: 0.25rem; box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);" class="alert alert-success">
                        <?php echo e(session('deleteMessage')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <a href="<?php echo e(route('news.create', app()->getLocale())); ?>" class="btn btn-success" style="margin-right: 20px">Add</a>

            <table class="table" style="font-family: arial, sans-serif;
                    border-collapse: collapse;
                    width: 100%; margin-top: 10px" >
                <tr class="categoryShow">
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">#</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Name Uz</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Name Ru</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Name En</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Photo</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Description Uz</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Description Ru</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Description En</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px; width: 133px;">Action</th>
                </tr>
                <?php $num=1; ?>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="categoryShow">
                        <td ><?php echo e($num++); ?></td>
                        <td ><?php echo e($rep->name_uz); ?></td>
                        <td><?php echo e($rep->name_ru); ?></td>
                        <td ><?php echo e($rep->name_en); ?></td>
                        <td ><?php echo e($rep->photo); ?></td>
                        <td ><?php echo e($rep->description_uz); ?></td>
                        <td ><?php echo e($rep->description_ru); ?></td>
                        <td ><?php echo e($rep->description_en); ?></td>

                        <td>
                            
                            

                        </td>
                        <div id="myModal<?php echo e($rep->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="myModalLabel">Rostdan ham o'chirmoqchimisiz?</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                        </button>
                                    </div>
                                    <div class="modal-body">

                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1056610/public_html/suu.u1056610.cp.regruhosting.ru/resources/views/news/index.blade.php ENDPATH**/ ?>