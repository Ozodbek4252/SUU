

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div style="margin-bottom: 1rem;">
                <?php if(session()->has('message')): ?>
                    <div style="padding: .75rem; background: #9ae6b4; color: #276749; border-radius: 0.25rem; box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);" class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php elseif(session()->has('deleteMessage')): ?>
                    <div style="padding: .75rem; background: #feb2b2; color: #9b2c2c; border-radius: 0.25rem; box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);" class="alert alert-success">
                        <?php echo e(session('deleteMessage')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <a href="<?php echo e(route('news.create', app()->getLocale())); ?>" class="btn btn-success" style="margin-right: 0px; margin-bottom: 20px;">Add News</a>

                <h4 class="card-title">News</h4>
                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                    </tr>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Photo</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $num=1; ?>
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($num++); ?></td>
                        <td><?php echo e($new->name_ru); ?></td>
                        <td><?php echo e($new->description_ru); ?></td>
                        <td style="display: flex; justify-content: center;"><img src="<?php echo e($new->image_path); ?>/<?php echo e($new->image); ?>" height="100" style="object-fit: contain; object-position: center;"></td>
                        <td><?php echo e($new->updated_at); ?></td>
                        <td>
                            <form action="<?php echo e(route('news.edit', [app()->getLocale(), $new->id] )); ?>" method="get" style="margin-bottom: 5px;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </form>
                            <a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#myModal<?php echo e($new->id); ?>">Delete</a>
                        </td>
                        <div id="myModal<?php echo e($new->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="myModalLabel">Rostdan ham o'chirmoqchimisiz?</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('news.destroy', [app()->getLocale(), $new->id] )); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">O'chirish</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($news->links()); ?>

            </div>
        </div>
    </div>
</div>





































<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU last\resources\views/news/index.blade.php ENDPATH**/ ?>