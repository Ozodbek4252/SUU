<div class="products-choose__item">
	<?php 
		$gazlilar = App\Models\Product::where('cat_id', '1')->get();
	?>
	<div class="products-choose__name">
		Газированная
	</div>
	
	<ul class="products-list">
		<?php $__currentLoopData = $gazlilar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gazli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<p wire:click="add"><?php echo e($a); ?></p>
				<div class="products-list__img products-list__img-big">
					<img src="<?php echo e($gazli->image_path); ?>/<?php echo e($gazli->image); ?>" alt="nogaz">
				</div>
				<div class="products-list__size">
					<?php echo e($gazli->size); ?> L
				</div>
				<div wire:click="addCart(<?php echo e($gazli->id); ?>)" class="products-list__basket">
					<img src="img/basket.png" alt="ico">
				</div>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
	</ul>
</div><?php /**PATH C:\wamp64\www\SUU\resources\views/livewire/order-product.blade.php ENDPATH**/ ?>