
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h1>List</h1>


            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>

            <table style="font-family: arial, sans-serif; border-collapse: collapse; width: 100%; margin-top: 10px" >
                <tr class="categoryShow">
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">#</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Name Uz</th>
                    
                    
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Size</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Price</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Description Uz</th>
                    
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Photo</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px; width: 133px;">Action</th>
                </tr>
                <?php $num=1; ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="categoryShow">
                        <td ><?php echo e($num++); ?></td>
                        <td ><?php echo e($product->name_uz); ?></td>
                        
                        
                        <td ><?php if($product->size): ?> <?php echo e($product->size); ?> L <?php endif; ?></td>
                        <td ><?php echo e($product->price); ?></td>
                        <td ><?php echo e($product->description_uz); ?></td>
                        
                        
                        <td ><?php echo e($product->photo); ?></td>
                        <td>
                            <form action="<?php echo e(route('product.edit', [app()->getLocale(), $product->id] )); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </form>

                            <a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#myModal<?php echo e($product->id); ?>">Delete</a>
        
                        </td>
                        <div id="myModal<?php echo e($product->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="myModalLabel">Rostdan ham o'chirmoqchimisiz?</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('product.destroy', [app()->getLocale(), $product->id] )); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">O'chirish</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>


        
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU\resources\views/product/list.blade.php ENDPATH**/ ?>