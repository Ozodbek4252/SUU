

<?php $__env->startSection('content'); ?>

     <div class="card">
         <div class="card-body">
            <h1>List</h1>


            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>

            <table style="font-family: arial, sans-serif;
                    border-collapse: collapse;
                    width: 100%; margin-top: 10px" >
                <tr class="categoryShow">
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">#</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Order_id</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Name</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Last Name</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Phone</th>
                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;">Message</th>


                    <th style="border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px; width: 133px;">Action</th>
                </tr>
                <?php $num=1; ?>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="categoryShow" >
                        <td ><?php echo e($num++); ?></td>
        
                        <td ><?php echo e($mess->name); ?></td>
                        <td><?php echo e($mess->last_name); ?></td>
                        <td ><?php echo e($mess->phone); ?></td>
                        <td ><?php echo e($mess->message); ?></td>
                        <td>
                            <a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#myModal<?php echo e($mess->id); ?>">Delete</a>

                        </td>
                        <div id="myModal<?php echo e($mess->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="myModalLabel">Rostdan ham o'chirmoqchimisiz?</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                        </button>
                                    </div>
                                    <div class="modal-body">

                                        <a href="<?php echo e(route('message.destroy', [app()->getLocale(), $mess->id] )); ?>" method="post">
                                            <button type="submit" class="btn btn-danger">O'chirish</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
         </div>
     </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SUU\resources\views/message/index.blade.php ENDPATH**/ ?>