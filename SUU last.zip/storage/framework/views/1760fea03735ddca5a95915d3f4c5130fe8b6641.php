<div class="basket-empty">
    <?php if(!session()->get('cart')): ?>
        ВАША КОРЗИНА ПУСТА
    <?php endif; ?>
</div>
<div class="basket-list" id="basket-list">
    <?php if(session()->get('cart')): ?>
        <?php $total_price = 0 ?>
        <?php $__currentLoopData = session()->get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $cart = session()->get('cart');
            $product = \App\Models\Product::find($key);
            $total_price += $product->price*$cart[$key]['quantity'];
            ?>
            <div class="basket-item">
                <div class="basket-item__delete" onclick="deleteProduct(<?php echo e($product->id); ?>)">
                    <img src="img/del.svg" alt="ico">
                </div>
                <div class="basket-item__img">
                    <img src="<?php echo e($product->image_path); ?>/<?php echo e($product->image); ?>" alt="img">
                </div>
                <div class="basket-item__wrap">
                    <div class="basket-item__size" id="basket-item__size'+i+'">
                        <?php if($product->category_id != 3): ?>
                            <?php echo e($product->price/6); ?>

                        <?php else: ?>
                            <?php echo e($product->price); ?>

                        <?php endif; ?>
                    </div>
                    <div class="basket-item__info">
                        <div class="basket-item__head">
                            <h2 class="basket-item__name">
                                <?php echo e(\App\Models\Category::find($product->category_id)['name_'.session()->get('locale')]); ?> (<?php echo e($product->size); ?>L)
                            </h2>
                            <div class="basket-item__price">итог 
                                <span>
                                    <strong id="price_product"><?php echo e($product->price*$cart[$key]['quantity']); ?></strong> UZS
                                </span>
                            </div>
                        </div>
                        <div class="basket-item__text">
                            <?php echo e($product['description_'.session()->get('locale')]); ?>

                        </div>
                        <div class="basket-item__logo btn">
                                        <span>
                                            <?php if($cart[$key]['logo'] == '0'): ?>
                                                <?php echo e(__('order.Без логотипа')); ?>

                                            <?php else: ?>
                                                <?php echo e(__('order.С вашим логотипом')); ?>

                                            <?php endif; ?>
                                        </span>
                            <svg width="11" height="11" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.41619 1.17401L5.29546 5.29474M1.17473 9.41547L5.29546 5.29474M5.29546 5.29474L9.26077 9.26005L1.12145 1.12073" stroke="#217BBE" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div class="basket-item__total">
                            <div id="capsula'+i+'"><?php if($product->category_id != 3): ?> 6 x <?php echo e($product->price/6); ?> = <?php endif; ?></div>
                            <div>
                                <strong id="price'+i+'"><?php echo e($product->price); ?></strong> UZS * <span id="capsula_name">
                                                <?php echo e($cart[$key]['quantity']); ?> <?php if($product->category_id != 3): ?> блок <?php else: ?> капсула <?php endif; ?>
                                            </span>
                            </div>
                        </div>
                        <div class="basket-item__open">
                            количество
                            <svg width="15" height="9" viewBox="0 0 15 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 1L7.5 7L1 1" stroke="#217BBE" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                        </div>
                        <div class="basket-item__dropdown">
                            <div class="order-thin">
                                <div class="order-item order-count">
                                    <div class="order-item__title">
                                        <?php echo e(__('order.Выберите количество блоков')); ?>

                                    </div>
                                    <select id="blok_quantity<?php echo e($product->id); ?>" onchange="quantity(<?php echo e($product->id); ?>)">
                                        <?php for($i=1; $i<5; $i++): ?>
                                            <option value="<?php echo e($i); ?>" <?php if($cart[$key]['quantity'] == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="order-item order-print">
                                    <div class="order-item__title">
                                        <?php echo e(__('order.Печать логотипа')); ?>

                                    </div>
                                    <div class="order-print__btns">
                                        <button class="btn <?php if($cart[$key]['logo'] == 1): ?> active <?php endif; ?>" onclick="logo(1, <?php echo e($product->id); ?>)" value="1"><?php echo e(__('order.С вашим логотипом')); ?></button>
                                        <button class="btn <?php if($cart[$key]['logo'] == 0): ?> active <?php endif; ?>" onclick="logo(0, <?php echo e($product->id); ?>)" value="0"><?php echo e(__('order.Без логотипа')); ?></button>
                                    </div>
                                    <div class="order-print__images">
                                        <div>
                                            <img src="img/print1.png" alt="img">
                                        </div>
                                        <div>
                                            <img src="img/print2.png" alt="img">
                                        </div>
                                    </div>
                                </div>
                                <div class="order-price">
                                    <div class="order-price__item">
                                        <span class="order-price__name"><?php echo e(__('order.honeOrderPrice')); ?></span>
                                        <span class="order-price__value" id="order-price__name'+i+'"><?php echo e($product->price*$cart[$key]['quantity']); ?><span>UZS</span></span>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php if(session()->get('cart')): ?>
<div class="basket-content" id="basket-content">
    <form action="<?php echo e(Route('order.create', session()->get('locale'))); ?>" class="basket-form">
      <div class="basket-form__title">
        <?php echo e(__('order.cartFormTitle')); ?>

      </div>
      <select name="customer" class="basket-form__select">
        <option value="new" selected><?php echo e(__('order.cartFormOption1')); ?></option>
        <option value="stand"><?php echo e(__('order.cartFormOption2')); ?></option>
      </select>
      <div class="form-half">
        <input name="name" type="text" placeholder="<?php echo e(__('order.homePlaceholderInputName')); ?>">
        <input name="phone" type="tel" placeholder="<?php echo e(__('order.homeContactPhone')); ?>" class="form__tel" maxlength="19" required="" pattern="^[0-9-+\s()]*$">
      </div>
      <div class="order-item order-delivery">
        <div class="order-item__title">
          <?php echo e(__('order.honeOrderDelivery')); ?>

        </div>

        <div class="order-delivery__btns">
          <button name="deliveryNeeded" class="btn active" type="button"><?php echo e(__('order.cartFormDelivery1')); ?></button>
          <button name="deliveryNoNeed" class="btn" type="button"><?php echo e(__('order.cartFormDelivery2')); ?></button>
        </div>
      </div>
      <div class="basket-form__price">
        <span><?php echo e(__('order.honeOrderPrice')); ?></span>
        <span></span>
        <span><strong id="total_price"><?php echo e($total_price); ?></strong> UZS</span>
      </div>
      <div class="basket-form__price">
        <span><?php echo e(__('order.honeOrderDelivery')); ?></span>
        <span></span>
        <span><strong>00</strong> UZS</span>
      </div>
      <div class="basket-form__choose">
        <div>
          <input type="radio" name="pay" id="cash"> <label for="cash"><?php echo e(__('order.cartFormPaymentM1')); ?></label>
        </div>
        <div>
          <input type="radio" name="pay" id="card"> <label for="card"><?php echo e(__('order.cartFormPaymentM2')); ?></label>
        </div>
      </div>
      <div class="basket-form__cards">
        <div class="basket-form__card active">
          <img src="img/click.png" alt="ico">
        </div>
        <div class="basket-form__card">
          <img src="img/payme.png" alt="ico">
        </div>
        <div class="basket-form__card">
          <img src="img/upay.png" alt="ico">
        </div>
        <div class="basket-form__card">
          <img src="img/paynet.png" alt="ico">
        </div>
        <div class="basket-form__card">
          <img src="img/apelsin.png" alt="ico">
        </div>
      </div>
      <button type="submit" class="order-add btn">
        <?php echo e(__('order.cartFormPayBtn')); ?>

      </button>
    </form>
    <div class="basket-info">
      <div class="basket-info__title">
        <?php echo e(__('order.cartReqTitle')); ?>

      </div>
      <ul class="basket-info__list">
        <li>
          <span><?php echo e(__('order.cartReqResip')); ?>:</span> OOO “SUU Tashkent”
        </li>
        <li>
          <span><?php echo e(__('order.footerAddress')); ?>:</span> <?php echo e(__('order.cartReqAddress')); ?>

        </li>
        <li>
          <span><?php echo e(__('order.cartReqTIN')); ?>:</span> 7706412841
        </li>
        <li>
          <span><?php echo e(__('order.cartReqBC')); ?>:</span> <?php echo e(__('order.cartReqBCBody')); ?>

        </li>
        <li>
          <span><?php echo e(__('order.cartReqIFI')); ?>:</span> 01075
        </li>
        <li>
          <span><?php echo e(__('order.cartReqTIN')); ?>:</span> 306 164 875
        </li>
        <li>
          <span><?php echo e(__('order.cartReqNCKEA')); ?>:</span> 58290
        </li>
      </ul>
    </div>
  </div>
<?php endif; ?>

    
        
        
        
        
    

<?php /**PATH /var/www/u1056610/public_html/suu.u1056610.cp.regruhosting.ru/resources/views/front/basket_refresh.blade.php ENDPATH**/ ?>