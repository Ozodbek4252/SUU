<div>
    In work, asssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssdo what you enjoy.
</div>
<?php /**PATH C:\wamp64\www\SUU\resources\views/livewire/index-part.blade.php ENDPATH**/ ?>